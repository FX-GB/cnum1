# cnum
Cálculo Numérico 
